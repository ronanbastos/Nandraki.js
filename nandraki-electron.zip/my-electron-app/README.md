# Manual

[Install requerimentos]{

    instalar nodejs
    instalar npm
    instalar electron

}

[Testar os arquivos]{

    Entre no terminal e coloque cd my-electron-app estando dentro da pasta digite npm start.

}

[Build]{
   
    https://www.electronjs.org/docs/tutorial/quick-start
    https://www.electronjs.org/docs/development/build-instructions-gn
    https://www.electronjs.org/docs/development/build-instructions-windows

}

